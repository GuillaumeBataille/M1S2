#define STB_IMAGE_IMPLEMENTATION
#include "../common/stb_image.h"
#include <string>
#include <vector>
#include <GL/glew.h>

GLuint loadTexture(const char *path)
{
    printf("Reading image %s\n", path);
    //  Data read from the header of the image file
    int width, height, numChannels;
    unsigned char *data = stbi_load(path, &width, &height, &numChannels, 0);

    if (!data)
    {
        printf("%s could not be opened or is not a valid image file.\n", path);
        return 0;
    }

    // Create one OpenGL texture
    GLuint textureID;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);

    // Give the image to OpenGL
    GLenum format;
    if (numChannels == 1)
    {
        format = GL_RED;
    }
    else if (numChannels == 3)
    {
        format = GL_RGB;
    }
    else if (numChannels == 4)
    {
        format = GL_RGBA;
    }
    else
    {
        printf("%s has an unsupported number of channels.\n", path);
        stbi_image_free(data);
        return 0;
    }

    glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);

    // Set texture filtering options
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // Generate mipmaps
    glGenerateMipmap(GL_TEXTURE_2D);

    return textureID;
}

GLuint loadTextureCube(std::vector<std::string> faces)
{
    // Create one OpenGL texture
    GLuint textureID;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_CUBE_MAP, textureID);

    // Load each face of the cube map
    int width, height, numChannels;
    for (GLuint i = 0; i < faces.size(); i++)
    {
        unsigned char *data = stbi_load(faces[i].c_str(), &width, &height, &numChannels, 0);
        if (!data)
        {
            printf("%s could not be opened or is not a valid image file.\n", faces[i].c_str());
            return 0;
        }
        GLenum format;
        if (numChannels == 1)
        {
            format = GL_RED;
        }
        else if (numChannels == 3)
        {
            format = GL_RGB;
        }
        else if (numChannels == 4)
        {
            format = GL_RGBA;
        }
        else
        {
            printf("%s has an unsupported number of channels.\n", faces[i].c_str());
            stbi_image_free(data);
            return 0;
        }
        glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
        stbi_image_free(data);
        std::cout << "Reading cube map :" << i << " done." << std::endl;
    }

    // Set texture filtering options
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    return textureID;
}

GLuint loadTextureCubeMono(const std::string &facePath)
{
    // Create one OpenGL texture
    GLuint textureID;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_CUBE_MAP, textureID);

    // Load the texture for each face of the cube map
    int width, height, numChannels;
    unsigned char *data = stbi_load(facePath.c_str(), &width, &height, &numChannels, 0);
    if (!data)
    {
        printf("%s could not be opened or is not a valid image file.\n", facePath.c_str());
        return 0;
    }
    GLenum format;
    if (numChannels == 1)
    {
        format = GL_RED;
    }
    else if (numChannels == 3)
    {
        format = GL_RGB;
    }
    else if (numChannels == 4)
    {
        format = GL_RGBA;
    }
    else
    {
        printf("%s has an unsupported number of channels.\n", facePath.c_str());
        stbi_image_free(data);
        return 0;
    }

    for (GLuint i = 0; i < 6; i++)
    {
        glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
    }

    stbi_image_free(data);

    // Set texture filtering options
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    return textureID;
}

std::vector<unsigned char> loadHeightmap(const char *path, int &width, int &height, int &nrChannels)
{
    stbi_set_flip_vertically_on_load(true); // Inverse l'axe Y pour que l'origine soit en bas à gauche

    // Chargement de l'image
    unsigned char *data = stbi_load(path, &width, &height, &nrChannels, STBI_rgb);
    if (!data)
    {
        std::cerr << "Impossible de charger l'image " << path << std::endl;
        exit(1);
    }
    std::cout << "height on : " << height << std::endl;
    // Récupération du canal rouge
    std::vector<unsigned char> result(width * height);
    for (int i = 0; i < width * height; i++)
    {
        result[i] = data[i * 3];
    }

    // Libération de la mémoire allouée par stb_image
    stbi_image_free(data);
    stbi_set_flip_vertically_on_load(false);
    return result;
}

float getGrayLevel(const std::vector<unsigned char> &data, int width, int height, float u, float v)
{
    int x = static_cast<int>(u * width);
    int y = static_cast<int>(v * height);
    /*std::cout << "height : " << height << std::endl;
    std::cout << "Valeur : X = " << x << " et Y = " << y << std::endl;
    std::cout << "Valeur : u = " << u << " et v = " << v << std::endl;
    std::cout << std::endl;*/

    x = glm::clamp(x, 0, width - 1);
    y = glm::clamp(y, 0, height - 1);

    return static_cast<float>(data[y * width + x]) / 255.0f;
}

float get_height_from_heightmap(const char *filename, float x, float z)
{
    int width, height, channels;
    // stbi_set_flip_vertically_on_load(false); // Inverse l'axe Y pour que l'origine soit en bas à gauche

    unsigned char *heightmap = stbi_load(filename, &width, &height, &channels, 4);
    if (!heightmap)
    {
        std::cerr << "Failed to load heightmap: " << filename << std::endl;
        return 0.0f;
    }

    // Convert the coordinates from float to integer
    int ix = (int)floor(x);
    int iz = (int)floor(z);

    // Clamp the coordinates to the range of the heightmap
    ix = std::max(std::min(ix, width - 1), 0);
    iz = std::max(std::min(iz, height - 1), 0);
    std::cout << " image : " << width << "x" << height << " --> x: " << ix << " et z: " << iz << std::endl;
    // Get the red channel of the heightmap pixel at the specified coordinates
    unsigned char red = heightmap[(int)(z * height + x) * 4];
    std::cout << "red ! " << red << std::endl;
    // Normalize the red value to the range [0, 1]
    float h = red / 255.0f;

    stbi_image_free(heightmap);
    return h;
}
float get_smoothed_height_from_heightmap(const char *filename, float x, float z)
{
    static float smoothed_height = 0.0f;
    static bool first_call = true;
    float current_height = get_height_from_heightmap(filename, x, z);
    if (first_call)
    {
        smoothed_height = current_height;
        first_call = false;
    }
    else
    {
        float smoothing_factor = 0.1f;
        smoothed_height = smoothed_height * (1.0f - smoothing_factor) + current_height * smoothing_factor;
    }
    return smoothed_height;
}
