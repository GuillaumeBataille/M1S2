#ifndef FUNCTION_H
#define FUNCTION_H

#include <unordered_map>
#include "map"
#include "Mesh.h"
#include "Writer.h"


Vec3 quantizeCoord(Vec3 coord, Vec3 minBounds, int quantizationParam, float range)
{
    Vec3 quantizedCoord = (coord - minBounds) * (pow(2, quantizationParam) / range);

    quantizedCoord[0] = round(quantizedCoord[0]);
    quantizedCoord[1] = round(quantizedCoord[1]);
    quantizedCoord[2] = round(quantizedCoord[2]);

    return quantizedCoord;
}

Vec3 dequantizeCoord(Vec3 coord, Vec3 minBounds, int quantizationParam, float range)
{
    return ((coord * range) / pow(2, quantizationParam)) + minBounds;
}

void quantize(Mesh &inputMesh, Mesh &outputMesh, int quantizationParam)
{
    float range = inputMesh.BB_Max[0] - inputMesh.BB_Min[0];
    if(inputMesh.BB_Max[1] - inputMesh.BB_Min[1] > range)
        range = inputMesh.BB_Max[1] - inputMesh.BB_Min[1];
    if(inputMesh.BB_Max[2] - inputMesh.BB_Min[2] > range)
        range = inputMesh.BB_Max[2] - inputMesh.BB_Min[2];

    for(int i = 0; i < inputMesh.vertices.size(); i++)
    {
        outputMesh.vertices[i].position = quantizeCoord(inputMesh.vertices[i].position, inputMesh.BB_Min, quantizationParam, range);
    }
}

void dequantize(Mesh &mesh, int quantizationParam)
{
    float range = mesh.BB_Max[0] - mesh.BB_Min[0];
    if(mesh.BB_Max[1] - mesh.BB_Min[1] > range)
        range = mesh.BB_Max[1] - mesh.BB_Min[1];
    if(mesh.BB_Max[2] - mesh.BB_Min[2] > range)
        range = mesh.BB_Max[2] - mesh.BB_Min[2];

    for(int i = 0; i < mesh.vertices.size(); i++)
    {
        mesh.vertices[i].position = dequantizeCoord(mesh.vertices[i].position, mesh.BB_Min, quantizationParam, range);
    }
}

float computeRMSE(Mesh mesh1, Mesh mesh2)
{
    float rmse = 0;

    for(int i = 0; i < mesh1.vertices.size(); i++)
    {
        rmse += pow(mesh1.vertices[i].position[0] - mesh2.vertices[i].position[0], 2);
        rmse += pow(mesh1.vertices[i].position[1] - mesh2.vertices[i].position[1], 2);
        rmse += pow(mesh1.vertices[i].position[2] - mesh2.vertices[i].position[2], 2);
    }

    rmse = sqrt(rmse / (3 * mesh1.vertices.size()));

    return rmse;
}

template<typename T>
int findIndexInVector(std::vector<T> vec, T element)
{
    for(int i = 0; i < vec.size(); i++)
    {
        if(vec[i] == element)
            return i;
    }
    return -1;
}
/* fonctionne pas
void rANS_buildArrays(std::vector<int> &sequence, std::vector<int> &alpha, std::vector<int> &alpha_freq, std::vector<int> &freqCumul, int &M)
{
    M = 0;

    for(int c : sequence)
    {
        int index = findInVector(alpha, c);
        if( index == -1)
        {
            alpha.push_back(c);
            alpha_freq.push_back(1);
        } else {
            alpha_freq[index]++;
        }

    }

    freqCumul.push_back(0);
    for(int i = 0; i < alpha_freq.size()-1; i++)
    {
        freqCumul.push_back(alpha_freq[i] + freqCumul[i]);
    }

    for(int el : alpha_freq){
        M += el;
    }
}

unsigned long int rANS_encode(std::vector<int> &sequence, std::vector<int> &alpha, std::vector<int> &alpha_freq, std::vector<int> &freqCumul, int &M)
{
    unsigned long int x = 0;

    for(int c : sequence)
    {
        int alpha_index = findInVector(alpha, c);
        x = floor(x/alpha_freq[alpha_index]) * M + freqCumul[alpha_index] + x % alpha_freq[alpha_index];
    }

    return x;
}

std::vector<int> rANS_decode(unsigned long long int encodedInt, std::vector<int> &alpha, std::vector<int> &alpha_freq, std::vector<int> &freqCumul, int &M)
{
    int n, st;
    std::vector<int> sequence;

    while (encodedInt != 0)
    {
        n = encodedInt % M;


        int alpha_index = findInVector(freqCumul, n);
        if(alpha_index != -1){
            st = alpha[alpha_index];
        } else {
            st = 0;
        }

        encodedInt = floor(encodedInt/M) * alpha_freq[st] + n - freqCumul[st];

        sequence.insert(sequence.begin(), st);
    }

    n = encodedInt % M;
    int alpha_index = findInVector(freqCumul, n);
    if(alpha_index != -1){
        st = alpha[alpha_index];
    } else {
        st = 0;
    }
    encodedInt = floor(encodedInt/M) * alpha_freq[st] + n - freqCumul[st];
    sequence.insert(sequence.begin(), st);

    return sequence;
}*/

#endif
